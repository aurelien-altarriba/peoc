var margin = {top: 20, right: 20, bottom: 30, left: 50},
    width = 960 - margin.left - margin.right,
    height = 500 - margin.top - margin.bottom;

var x = d3.scale.linear()
    .range([0, width]);

var y = d3.scale.linear()
    .range([height, 0]);

var xAxis = d3.svg.axis()
    .scale(x)
    .orient("bottom");

var yAxis = d3.svg.axis()
    .scale(y)
    .orient("left");

var area = d3.svg.area()
    .x(function(d) { return x(d.dist); })
    .y0(height)
    .y1(function(d) { return y(d.alts.DTM25); });

var svg = d3.select("body").append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
  .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

d3.json('profile.json', function(data) {
  x.domain(d3.extent(data, function(d) { return d.dist; }));
  y.domain([0, d3.max(data, function(d) { return d.alts.DTM25; })]);

  svg.append("path")
      .datum(data)
      .attr("class", "area")
      .attr("d", area);

  svg.append("g")
      .attr("class", "x axis")
      .attr("transform", "translate(0," + height + ")")
      .call(xAxis);

  svg.append("g")
      .attr("class", "y axis")
      .call(yAxis)
    .append("text")
      .attr("transform", "rotate(-90)")
      .attr("y", 6)
      .attr("dy", ".71em")
      .style("text-anchor", "end")
      .text("Elevation");

  var poi = [5000, 700, 'Mont de la Touffe'];

  data.forEach(function(d) {
      if (d.poi) {
          var poi = svg.append("g")
          .attr("class", "poi");

          poi.append("text")
              .attr("x", 9)
              .attr("dy", ".35em")
              .attr("transform", "rotate(-60)");
          poi.attr("transform", "translate(" + x(d.dist) + "," + (y(d.alts.DTM25) - 20) + ")");
          poi.select("text").text([d.poi, d.alts.DTM25 + 'm'].join(' - '));

          // FIXME use only one group
          var poiLine = svg.append("g");
          poiLine.append("svg:line")
             .attr("class", "poi")
             .attr("x1", x(d.dist))
             .attr("y1", y(0))
             .attr("x2", x(d.dist))
             .attr("y2", y(d.alts.DTM25));

          poiLine.append("svg:line")
             .attr("class", "poi2")
             .attr("x1", x(d.dist))
             .attr("y1", y(d.alts.DTM25))
             .attr("x2", x(d.dist))
             .attr("y2", y(d.alts.DTM25) - 20);
      }
  });

});